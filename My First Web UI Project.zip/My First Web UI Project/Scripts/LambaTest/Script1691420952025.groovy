import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import org.openqa.selenium.WebDriver as WebDriver
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.lambdatest.com/')

WebUI.maximizeWindow()

WebUI.waitForElementVisible(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/see_all_integration'), 30)

String url = WebUI.getAttribute(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/see_all_integration'),"href")

println url

WebUI.scrollToElement(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/see_all_integration'), 2, FailureHandling.STOP_ON_FAILURE)

String l = Keys.chord(Keys.CONTROL,Keys.ENTER);

WebUI.sendKeys(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/see_all_integration'), l)

WebDriver driver1 = DriverFactory.getWebDriver()
String mainWindowHandle = driver1.getWindowHandle();
String title1= driver1.getTitle()
System.out.println("Title of Main window is :" + title1)
System.out.println("Main window handle is : " + mainWindowHandle)

Set<String> allWindowHandles = driver1.getWindowHandles();
Iterator<String> iterator = allWindowHandles.iterator();

while (iterator.hasNext()) {
	String ChildWindow = iterator.next()
		if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
		driver1.switchTo().window(ChildWindow);
		String title= driver1.getTitle()
		System.out.println("Title of child window is : " + title)
		System.out.println("Child window handle is  :" + ChildWindow)
	}
}

WebUI.verifyMatch(url,WebUI.getUrl() , false)


WebUI.click(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/allow_cookies'))

WebUI.scrollToElement(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/codeless_automation'), 10)

WebUI.click(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/codeless_automation'))


WebUI.scrollToElement(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/testing_whiz_header'), 2)

WebUI.click(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/testing_whiz'))

WebUI.waitForPageLoad(5)

WebUI.verifyMatch("Running Automation Tests Using TestingWhiz LambdaTest | LambdaTest", WebUI.getWindowTitle(), false)


WebUI.closeWindowIndex(WebUI.getWindowIndex())

Set<String> allWindowHandle = driver1.getWindowHandles();
ArrayList<String> tabs = new ArrayList<String>(allWindowHandle);
println tabs.size()


WebUI.switchToDefaultContent()

WebUI.navigateToUrl("https://www.lambdatest.com/blog")


WebUI.click(findTestObject('Object Repository/repo/Page_Next-Generation Mobile Apps and Cross _484575/community'))


WebUI.verifyMatch("https://community.lambdatest.com/", WebUI.getUrl(), false)



WebUI.closeBrowser()
