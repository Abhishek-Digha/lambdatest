<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>codeless_automation</name>
   <tag></tag>
   <elementGuidId>52eae627-d50b-4b80-b138-a964eb05b2fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#__next > div.wrapper > section.pb-0.integration > div > div > div.w-full.sm\:w-3\/12.pr-30.left_bar > div > ul > li:nth-child(5) > a</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
