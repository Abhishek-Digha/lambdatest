<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>community</name>
   <tag></tag>
   <elementGuidId>5d3e7763-0fc7-4913-b3b2-57016b36f649</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'menu-item-10121']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>menu-item-10121</value>
      <webElementGuid>98ca72e4-8e27-479d-899f-a5886ec128b0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
