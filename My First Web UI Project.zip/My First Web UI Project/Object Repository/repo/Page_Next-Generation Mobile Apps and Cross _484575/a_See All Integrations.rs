<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_See All Integrations</name>
   <tag></tag>
   <elementGuidId>5687a3ba-def0-497a-ad43-88ee5aa66030</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@href = 'https://www.lambdatest.com/integrations' and (text() = 'See All Integrations' or . = 'See All Integrations')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c80e3e74-472a-4a6a-9853-64acc07adca9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.lambdatest.com/integrations</value>
      <webElementGuid>a9fcc6e7-0e37-40cc-8fbe-2cf2ce1514c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>uppercase font-bold text-black text-size-16 tracking-widest inline-block hover:underline</value>
      <webElementGuid>d9de2883-a612-4219-a3d9-8320b3021815</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>See All Integrations</value>
      <webElementGuid>35ff90d5-fa1b-43ee-b1ab-ff1aa364427d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/div[@class=&quot;wrapper&quot;]/section[@class=&quot;bg-white relative&quot;]/div[@class=&quot;container relative&quot;]/div[@class=&quot;clearfix&quot;]/div[@class=&quot;m-70 smtablet:m-0&quot;]/div[@class=&quot;text-center mt-25&quot;]/a[@class=&quot;uppercase font-bold text-black text-size-16 tracking-widest inline-block hover:underline&quot;]</value>
      <webElementGuid>37c90187-8830-47fb-b898-fd096889346b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/div/section[7]/div/div/div/div/a</value>
      <webElementGuid>42b35745-be68-4fa7-9c39-276fc0685c0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'See All Integrations')]</value>
      <webElementGuid>15821f3c-33a1-47bd-b049-9b834128d490</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Seamless Collaboration'])[1]/following::a[1]</value>
      <webElementGuid>c1c326f4-1f57-466e-a63b-588c17eafdef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='documentation'])[1]/following::a[1]</value>
      <webElementGuid>10879492-708a-4927-abe6-e50cf69ef8b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='See more'])[1]/preceding::a[1]</value>
      <webElementGuid>d32745d3-d317-4e3a-80c4-3ec7cb1f12f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trepp'])[1]/preceding::a[2]</value>
      <webElementGuid>5d2cc85f-dda8-41fe-86bc-71e5fff4dc7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='See All Integrations']/parent::*</value>
      <webElementGuid>c118af52-60ea-4d1d-af7f-097126ff1783</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://www.lambdatest.com/integrations')])[3]</value>
      <webElementGuid>279e0044-7619-48ec-8438-da4b9d8b13c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section[7]/div/div/div/div/a</value>
      <webElementGuid>240d3547-585a-4847-a8b0-11635b6f4805</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.lambdatest.com/integrations' and (text() = 'See All Integrations' or . = 'See All Integrations')]</value>
      <webElementGuid>d170f0ce-5280-44b2-9e67-f5ea9055bab2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
